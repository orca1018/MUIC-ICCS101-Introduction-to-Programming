class Food:
    pass
