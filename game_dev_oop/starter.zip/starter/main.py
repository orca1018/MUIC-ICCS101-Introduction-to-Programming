from Game import Game

game = Game()
game.run()
