class Game:
    pass
