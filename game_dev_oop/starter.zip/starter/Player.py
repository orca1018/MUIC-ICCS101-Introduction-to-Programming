class Player:
    pass