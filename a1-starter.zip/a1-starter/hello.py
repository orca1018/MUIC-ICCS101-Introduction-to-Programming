# Assignment 1, Task 2
# Name: <YOUR NAME>
# Collaborators: <NAME_1, NAME_2>
# Time Spent: 4:00 hrs
# Use of AI: <YES/NO>
# AI usage details: <DETAILS>

### Your code start here ######

# Step 1: Prompt the user to input his/her name

# Step 2: Print out the greeting
