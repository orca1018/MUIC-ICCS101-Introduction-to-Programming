# Assignment 1, Task 5
# Name: <YOUR NAME>
# Collaborators: <NAME_1, NAME_2>
# Time Spent: 4:00 hrs
# Use of AI: <YES/NO>
# AI usage details: <DETAILS>

### Your code start here ######

# Step 1: Read p and q from the console

# Step 2: Compute the area

# Step 3: Print out the result
